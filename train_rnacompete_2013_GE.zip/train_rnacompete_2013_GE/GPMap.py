#%%capture
import sys
sys.path.insert(0, '../mavenn')
import mavenn
from mavenn.src.error_handling import check, handle_errors
from mavenn.src.entropy import mi_continuous, mi_mixed, entropy_continuous
from mavenn import TINY

import keras
from keras import Input, Layer, ops
from keras.initializers import Constant, GlorotUniform
from keras.constraints import NonNeg
from keras.regularizers import Regularizer

import time
import numpy as np
import re
from abc import ABC, abstractmethod
from typing import Optional

import os
import helper

class GPMap(keras.Layer, ABC):
    """
    Abstract base class for genotype-phenotype (GP) map layers. Specific implementations 
    (linear, MLP, biophysical) must inherit from this class and implement the 
    required interface methods.
    """

    # Methods that need to be overriden by child classes
    def __init__(self, 
                 theta_regularizer: Optional[Regularizer] = None,
                 phi_dim: int = 1, 
                 **kwargs):
        """
        Initialize GP map layer.

        Parameters
        ----------
        theta_regularizer : keras.regularizers.Regularizer
            Regularizer for layer weights.
        phi_dim : int, default=1
            Dimension of the latent phenotype space.
            Determines output shape and weights dimensions.
        """
        super().__init__(**kwargs)

        # Layer configuration
        self.theta_regularizer = theta_regularizer  
        self.phi_dim = phi_dim 

        check((self.phi_dim >= 0) and isinstance(self.phi_dim, int),
              f'self.phi_dim={repr(self.phi_dim)}; must be '
              f'a non-negative integer')

        # Initialize mask for meaningless weights
        self.mask_dict = {}
        
        # Set regex pattern to identify specific weights (i.e. thetas)
        self.theta_pattern = re.compile('^theta.*')
        
    def get_config(self):
        """Return layer configuration for serialization."""
        config = super().get_config()
        config.update(
            {"theta_regularizer": self.theta_regularizer,
             "phi_dim": self.phi_dim}
        )
        return config
    
    def set_params(self, **kwargs):
        """
        Set values of layer weights.
        
        Parameters
        ----------
        **kwargs : dict
            Key-value pairs of weight names and their values.
            If a key matches any name in mask_dict, the provided value
            matrix will be masked accordingly.
        """
        pass
        
    def get_params(self, mask_with_nans=True):
        """
        Get values of layer weights.
        
        Parameters
        ----------
        mask_with_nans : bool, default=True
            If True, meaningless weight values will be masked with NaN.
            
        Returns
        -------
        dict
            Dictionary of weight values.
        """
        pass
        
    def x_to_phi(self,
                 x,
                 batch_size: Optional[int] = 64):
        """
        Compute latent phenotype values in batches.
        
        A batched version of the call() method to prevent memory overflow.
        
        Parameters
        ----------
        x : np.ndarray/ tensor
            Input one-hot encoded sequences.
        batch_size : int, optional, default=64
            Number of samples to process in each batch.

        Returns
        -------
        tensor
            Latent phenotype values, shape (batch_size, phi_dim).
        """
        num_samples = x.shape[0]
        outputs = []

        for start_idx in range(0, num_samples, batch_size):
            end_idx = min(start_idx + batch_size, num_samples)
            x_batch = x[start_idx:end_idx]
            phi_batch = self.call(x_batch)
            outputs.append(phi_batch)

        return ops.concatenate(outputs, axis=0)
    
    # Abstract methods - must be implemented by child classes
    @abstractmethod
    def build(self, input_shape):
        """Initialize layer weights"""
        pass

    @abstractmethod
    def call(self, inputs):
        """
        Define the forward pass computation.
        
        Parameters
        ----------
        inputs : tf.Tensor
            Input tensor.
            
        Returns
        -------
        tf.Tensor
            Latent phenotype values, shape (batch_size, phi_dim).
        """
        pass



class LinearGP(GPMap):

    @handle_errors
    def __init__(self,
                 phi_dim: int = 1,
                 theta_regularizer: Optional[Regularizer] = None,
                 interaction_type: str = 'additive',   # must be an option from 'additive', 'pairwise', 'neighbor', 'k_order’
                 interaction_order: Optional[int] = 1,
                 **kwargs):
        
        super().__init__(phi_dim=phi_dim, 
                         theta_regularizer=theta_regularizer, 
                         **kwargs)
        
        self.interaction_type = interaction_type
        self.interaction_order = interaction_order

        check(self.interaction_type in ['additive', 'pairwise', 'neighbor', 'k_order'],
              f'self.interaction_type={repr(self.interaction_type)}; must be '
              f'one of ["additive", "pairwise", "neighbor", "k_order"]')

        # # Force interaction_order=2 for neighbor and pairwise types
        # self.interaction_order = 2 if self.interaction_type in ['neighbor', 'pairwise'] else self.interaction_order
        
        check((self.interaction_order >= 0) and isinstance(self.interaction_order, int),
              f'self.interaction_order={repr(self.interaction_order)}; must be '
              f'a non-negative integer')

        
    @handle_errors
    def build(self, input_shape):
        # expect an input shape of (batch, length, channel)
        self.L = input_shape[-2]
        self.C = input_shape[-1]

        theta_shape = (1, self.phi_dim)  # Start with batch and node dims
        seq_len_arange = np.arange(self.L).astype(int)
        
        # define weights based on phi_dim, interatcion_type, interaction_order
        self.theta_dict = {
            'theta_0': self.add_weight(
                name='theta_0',
                shape=theta_shape,
                initializer='zeros',
                trainable=True,
                regularizer=self.theta_regularizer
            )
        } 
        
        # Add weights for each interaction order
        for k in range(self.interaction_order):
            theta_name = f'theta_{k+1}'
            # Shape: [1, phi_dim, L, C, (L, C)...] based on order k
            theta_shape = theta_shape + (self.L,self.C)
            self.theta_dict[theta_name] = self.add_weight(
                name=theta_name,
                shape=theta_shape,
                initializer='glorot_uniform',
                trainable=True,
                regularizer=self.theta_regularizer
            )

            # Create list of indices
            ls_dict = {}
            # starting location of L,C characters in the shape lists
            lc_loc = 2  # Start after batch and node dims
            for w in range(k + 1):
                ls_part_shape = [1] * len(theta_shape)
                ls_tile_shape = list(theta_shape)
                ls_part_shape[lc_loc] = self.L
                ls_tile_shape[lc_loc] = 1
                ls = np.tile(
                    seq_len_arange.reshape(ls_part_shape), 
                    ls_tile_shape
                )
                ls_dict[f'ls_{w}'] = ls
                lc_loc = lc_loc + 2
    
            # Create masks for ordering
            # m_dict = {}
            # for w in range(k):
            #     m_dict[f'm_{w}'] = ls_dict[f'ls_{w+1}'] > ls_dict[f'ls_{w}']

            m_dict = {}
            if self.interaction_type == 'neighbor':
                # For neighbor interactions, we want consecutive positions
                for w in range(k):
                    # Check if positions are consecutive
                    m_dict[f'm_{w}'] = (ls_dict[f'ls_{w+1}'] - ls_dict[f'ls_{w}'] == 1)
            else:
                # Original ordering for other interaction types
                for w in range(k):
                    m_dict[f'm_{w}'] = ls_dict[f'ls_{w+1}'] > ls_dict[f'ls_{w}']
    
            # Combine masks
            mask = True
            for key in m_dict.keys():
                mask = m_dict[key] * mask
                
            # The mask will automatically broadcast across node dimension
            self.mask_dict[theta_name] = mask
    
    def call(self, x_lc):
        """Process layer input and return output."""

        # Get the interaction order
        interaction_order = self.interaction_order

        # 0-th order interaction
        theta_0_name = f'theta_0'
        phi = self.theta_dict[theta_0_name]

        # Loop over interaction order
        theta_shape = (1,self.phi_dim)

        for k in range(interaction_order):
            theta_name = f'theta_{k+1}'
            theta_shape = theta_shape + (self.L, self.C)
            # Find the axis shape (order) which we should sum the array
            axis_shape = np.arange(2, len(theta_shape))
            # Location of L, C char in x_lc reshape arguments
            lc_loc = 2
            # To find interactions we need to find x_lc*x_l'c'*...
            # Here we call that multiplication x_mult
            x_mult = 1
            for w in range(k + 1):
                # Find the shape of x_lc
                x_shape_k_order = [1] * len(theta_shape)
                x_shape_k_order[0] = -1
                x_shape_k_order[lc_loc] = self.L
                x_shape_k_order[lc_loc + 1] = self.C
                x_mult = x_mult *ops.reshape(x_lc, x_shape_k_order)
                lc_loc = lc_loc + 2

            phi = phi + \
                ops.reshape(
                    ops.sum(self.theta_dict[theta_name] * self.mask_dict[theta_name] * x_mult, axis=axis_shape), [-1, self.phi_dim])

        return phi
    
    def get_config(self):
        """Return layer configuration for serialization."""
        # Get parent class config (includes phi_dim and theta_regularizer)
        config = super().get_config()
    
        # Add only the new parameters specific to linearGP
        config.update({
            "interaction_type": self.interaction_type,
            "interaction_order": self.interaction_order
        })
        return config
