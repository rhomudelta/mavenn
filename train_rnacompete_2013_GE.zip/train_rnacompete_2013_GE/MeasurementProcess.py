#%%capture
import sys
sys.path.insert(0, '../mavenn')
import mavenn
from mavenn.src.error_handling import check, handle_errors
from mavenn.src.entropy import mi_continuous, mi_mixed, entropy_continuous
from mavenn import TINY

import keras
from keras import Input, Layer, ops
from keras.initializers import Constant, GlorotUniform
from keras.constraints import NonNeg
from keras.regularizers import Regularizer

import time
import numpy as np
import re
from abc import ABC, abstractmethod
from typing import Optional
import sklearn
from scipy import stats
from scipy.stats import expon
import matplotlib.pyplot as plt

import os
import helper

# MP imports
from keras.constraints import NonNeg
from keras.initializers import GlorotUniform, RandomUniform
from keras.regularizers import L2

from scipy.special import betaincinv

pi = np.pi
e = np.exp(1)

# To clarify equations
# Log = ops.log
# LogGamma = tf.math.lgamma/torch.lgamma depending on the chosen backend
# Exp = ops.exp

# TODO: check ops operations are defined correctly
Sqrt = ops.sqrt
Square = ops.square

# MAX_EXP_ARG = np.float32(20.0)
MAX_EXP_ARG = np.float32(50.0)
MIN_LOG_ARG = np.float32(np.exp(-MAX_EXP_ARG))

# Create safe functions


def Log(x):
    x = ops.clip(x, MIN_LOG_ARG, np.inf)
    return ops.log(x)


def Log10(x):
    x = ops.clip(x, MIN_LOG_ARG, np.inf)
    #return K.log(x)/K.log(tf.constant(10.0, dtype=tf.float32))
    return ops.log(x) / ops.log(10.0)


def Exp10(x):
    x = ops.clip(x, -MAX_EXP_ARG, MAX_EXP_ARG)
    x = ops.cast(x, dtype='float32')
    return ops.power(10.0, x)


def LogGamma(x):
    """Implementation of log gamma function that works with both TF and PyTorch backends"""
    x = ops.clip(x, MIN_LOG_ARG, np.inf)
    if keras.backend.backend() == 'tensorflow':
        import tensorflow as tf
        return tf.math.lgamma(x)
    elif keras.backend.backend() == 'torch':
        import torch
        return torch.lgamma(x)
    else:
        raise NotImplementedError(f"LogGamma not implemented for backend: {keras.backend.backend()}")


def Exp(x):
    x = ops.clip(x, -MAX_EXP_ARG, MAX_EXP_ARG)
    x = ops.cast(x, dtype='float32')
    return ops.exp(x)



class MeasurementProcess(keras.Layer, ABC):
    
    def __init__(self, **kwargs):
        """Initialize MeasurementProcess layer."""
        super().__init__(**kwargs)

    @abstractmethod
    def build(self):
        pass

    def get_config(self):
        """Get base configuration."""
        base_config = super().get_config()
        return base_config or {}  # Return empty dict if base_config is None
        
    def get_params(self):
        pass
        
    def set_params(self):
        pass

    @abstractmethod
    def p_of_y_given_phi(self):
        pass

    @abstractmethod
    def sample_y_given_phi(self):
        pass
        
    @abstractmethod    
    def negative_log_likelihood(self):
        pass

    @abstractmethod
    def call(self):
        pass




class PhaseTransitionCallback(keras.callbacks.Callback):
    def __init__(self, first_phase_patience, second_phase_patience):
        super().__init__()
        
        if not isinstance(first_phase_patience, int) or first_phase_patience < 0:
            raise ValueError("first_phase_patience must be non-negative integer")
        if not isinstance(second_phase_patience, int) or second_phase_patience < 0:
            raise ValueError("second_phase_patience must be non-negative integer")
            
        self.first_phase_patience = first_phase_patience
        self.second_phase_patience = second_phase_patience
        self.best_loss = float('inf')
        self.wait = 0
        self.phase_switched = (first_phase_patience == 0)
        self.best_weights = None  # Track best weights

    def _find_mp_layer(self):
        mp_layers = [l for l in self.model.layers if isinstance(l, ContinuousMP)]
        if not mp_layers:
            raise ValueError("No ContinuousMP layer found in model")
        return mp_layers
        
    def on_train_begin(self, logs=None):
        mp_layers = self._find_mp_layer()
        for layer in mp_layers:
            if self.first_phase_patience == 0:
                # Start directly with NLL loss
                layer.use_mse_loss.assign(False)
                layer.use_layer_loss.assign(True)
                print(f"Starting with NLL phase: use_mse_loss={layer.use_mse_loss.numpy()}, use_layer_loss={layer.use_layer_loss.numpy()}")
            else:
                # Start with MSE phase
                layer.use_mse_loss.assign(True)
                layer.use_layer_loss.assign(False)
                print(f"Starting MSE phase: use_mse_loss={layer.use_mse_loss.numpy()}, use_layer_loss={layer.use_layer_loss.numpy()}")
            

    def on_epoch_end(self, epoch, logs=None):
        current_loss = logs.get('val_loss')
        if current_loss is None:
            raise ValueError("Validation loss not found in logs")
            
        if not np.isfinite(current_loss):
            print("\nStopping training: Invalid loss value")
            self.model.stop_training = True
            if self.best_weights is not None:
                self.model.set_weights(self.best_weights)
            return
            
        if not self.phase_switched:
            # First phase (MSE)
            if current_loss < self.best_loss:
                self.best_loss = current_loss
                self.wait = 0
                self.best_weights = self.model.get_weights()
            else:
                self.wait += 1
                
            # Check if we should switch phases
            if self.wait >= self.first_phase_patience:
                print("\nSwitching to NLL phase...")
                self.phase_switched = True
                self.wait = 0  # Reset counter for second phase
                self.best_loss = float('inf')  # Reset best loss for new phase
                self.best_weights = None  # Reset best weights for new phase

                # Switch to NLL loss
                mp_layers = self._find_mp_layer()
                for layer in mp_layers:
                    layer.use_mse_loss.assign(False)
                    layer.use_layer_loss.assign(True)
                    print(f"Now in NLL phase: use_mse_loss={layer.use_mse_loss.numpy()}, use_layer_loss={layer.use_layer_loss.numpy()}")
                    
        else:
            # Second phase (NLL)
            if current_loss < self.best_loss:
                self.best_loss = current_loss
                self.wait = 0
                self.best_weights = self.model.get_weights()  # Save weights
            else:
                self.wait += 1
                
            if self.wait >= self.second_phase_patience:
                print("\nStopping training: no improvement in NLL phase") 
                if self.best_weights is not None:
                    self.model.set_weights(self.best_weights)
                self.model.stop_training = True



class PhaseTransitionCallback(keras.callbacks.Callback):
    def __init__(self, first_phase_patience, second_phase_patience):
        super().__init__()
        
        if not isinstance(first_phase_patience, int) or first_phase_patience < 0:
            raise ValueError("first_phase_patience must be non-negative integer")
        if not isinstance(second_phase_patience, int) or second_phase_patience < 0:
            raise ValueError("second_phase_patience must be non-negative integer")
            
        self.first_phase_patience = first_phase_patience
        self.second_phase_patience = second_phase_patience
        self.best_loss = float('inf')
        self.wait = 0
        self.phase_switched = (first_phase_patience == 0)
        self.best_weights = None  # Track best weights

    def _find_mp_layer(self):
        mp_layers = [l for l in self.model.layers if isinstance(l, ContinuousMP)]
        if not mp_layers:
            raise ValueError("No ContinuousMP layer found in model")
        return mp_layers
        
    def on_train_begin(self, logs=None):
        mp_layers = self._find_mp_layer()
        for layer in mp_layers:
            if self.first_phase_patience == 0:
                # Start directly with NLL loss
                layer.use_mse_loss.assign(False)
                layer.use_layer_loss.assign(True)
                print(f"Starting with NLL phase: use_mse_loss={layer.use_mse_loss.numpy()}, use_layer_loss={layer.use_layer_loss.numpy()}")
            else:
                # Start with MSE phase
                layer.use_mse_loss.assign(True)
                layer.use_layer_loss.assign(False)
                print(f"Starting MSE phase: use_mse_loss={layer.use_mse_loss.numpy()}, use_layer_loss={layer.use_layer_loss.numpy()}")
            

    def on_epoch_end(self, epoch, logs=None):
        current_loss = logs.get('val_loss')
        if current_loss is None:
            raise ValueError("Validation loss not found in logs")
            
        if not np.isfinite(current_loss):
            print("\nStopping training: Invalid loss value")
            self.model.stop_training = True
            if self.best_weights is not None:
                self.model.set_weights(self.best_weights)
            return
            
        if not self.phase_switched:
            # First phase (MSE)
            if current_loss < self.best_loss:
                self.best_loss = current_loss
                self.wait = 0
                self.best_weights = self.model.get_weights()
            else:
                self.wait += 1
                
            # Check if we should switch phases
            if self.wait >= self.first_phase_patience:
                print("\nSwitching to NLL phase...")
                self.phase_switched = True
                self.wait = 0  # Reset counter for second phase
                self.best_loss = float('inf')  # Reset best loss for new phase
                self.best_weights = None  # Reset best weights for new phase

                # Switch to NLL loss
                mp_layers = self._find_mp_layer()
                for layer in mp_layers:
                    layer.use_mse_loss.assign(False)
                    layer.use_layer_loss.assign(True)
                    print(f"Now in NLL phase: use_mse_loss={layer.use_mse_loss.numpy()}, use_layer_loss={layer.use_layer_loss.numpy()}")
                    
        else:
            # Second phase (NLL)
            if current_loss < self.best_loss:
                self.best_loss = current_loss
                self.wait = 0
                self.best_weights = self.model.get_weights()  # Save weights
            else:
                self.wait += 1
                
            if self.wait >= self.second_phase_patience:
                print("\nStopping training: no improvement in NLL phase") 
                if self.best_weights is not None:
                    self.model.set_weights(self.best_weights)
                self.model.stop_training = True



class ContinuousMP(MeasurementProcess):
    def __init__(self, 
                 num_hidden_nodes: int = 50, 
                 alpha_regularizer: Optional[Regularizer] = None,
                 beta_regularizer: Optional[Regularizer] = None,  # Separate regularizer for noise layer weights
                 monotonic: bool = True, 
                 phi_mapping: str = 'non-linear',  # TODO: implement 'linear' (affine) and 'identity' (discuss with Justin)
                 ge_noise_model: str = 'Gaussian',
                 ge_heteroskedasticity_order: int = 0, 
                 use_empirical_noise: bool = False,
                 return_type: str = 'dist_params',
                 H_y: float = None,    # TODO: make this optional
                 **kwargs):
        """
        Implements a measurement process for continuous-valued measurements.
        
        This layer combines a GlobalEpistasisLayer for feature transformation (phi->yhat) 
        with a noise model layer to generate the full measurement process distribution p(y|phi).
        
        Args:
            num_hidden_nodes: Number of hidden nodes in GE layer (default: 50)   
            alpha_regularizer: Regularizer for GE layer            
            beta_regularizer: Regularizer for noise layer (defaults to alpha_regularizer if None)           
            monotonic: Whether to enforce monotonicity in GE layer            
            phi_mapping: Type of GE mapping from phi to yhat:
                       - 'non-linear': Sum of tanh transformations
                       - 'linear': Standard linear transformation
                       - 'identity': Identity mapping            
            ge_noise_model: Type of noise model:
                           - 'Gaussian': Normal distribution, with the option to use empirical noise/std
                           - 'Cauchy': Cauchy distribution
                           - 'SkewedT': Skewed T distribution
            ge_heteroskedasticity_order: Order of heteroskedasticity polynomial
            use_empirical_noise: Whether to use empirical noise values (only valid for Gaussian noise model)
            return_type: Output type: 
                        - 'nlls': Return negative log likelihoods (batch_size, 1), 
                        - 'dist_params': Returns yhat, and other dist params (batch_size, num_params)

        Input shape:
            phi: (batch_size, phi_dim) : Input tensor (phi) returned by GPMap
            y: (batch_size, 1) : Target values
            empirical_noise: Optional (batch_size, 1) : Empirical noise values
        
        Output shape:
            if return_type == 'nlls':
                (batch_size, 1) : Negative log likelihoods
            else:
                (batch_size, 1) x number of dist params: For example, a Gaussian noise model would have two (batch,1) output tensors, one for yhat and the other for sigma/std

        Example:
            # Basic usage with non-linear mapping
            mp = ContinuousMP(
                num_hidden_nodes=50,
                monotonic=True,
                phi_mapping='non-linear',
                ge_noise_model='gaussian')
        """
        
        super().__init__(**kwargs)

        self.num_hidden_nodes = num_hidden_nodes
        self.alpha_regularizer = alpha_regularizer
        self.beta_regularizer = beta_regularizer or alpha_regularizer  # Use alpha_regularizer if none provided
        self.monotonic = monotonic
        self.phi_mapping = phi_mapping.lower()  # TODO: implement this, only takes 'non-linear' currently
        self.ge_noise_model = ge_noise_model.lower()
        self.ge_heteroskedasticity_order = ge_heteroskedasticity_order  
        self.use_empirical_noise = use_empirical_noise
        self.return_type = return_type.lower()  # TODO: implement this, only outputs NLLs (batch_size, 1) currently
        self.H_y = H_y
        
        # Loss switching for pre-training with MSE loss and then the actual NLL
        self.use_mse_loss = keras.Variable(False, trainable=False, dtype='bool', name='use_mse_loss')
        self.use_layer_loss = keras.Variable(True, trainable=False, dtype='bool', name='use_layer_loss')
        
        # Create sublayers
        self.ge_layer = GlobalEpistasisLayer(
            num_hidden_nodes=self.num_hidden_nodes,
            alpha_regularizer=self.alpha_regularizer,
            monotonic=self.monotonic,
            phi_mapping=self.phi_mapping)

        if self.ge_noise_model == 'gaussian':
            self.noise_layer = GaussianNoise(
                ge_heteroskedasticity_order=self.ge_heteroskedasticity_order,
                beta_regularizer=self.beta_regularizer,
                use_empirical_noise=self.use_empirical_noise)
            
        elif self.ge_noise_model =='cauchy':
            self.noise_layer = CauchyNoise(
                ge_heteroskedasticity_order=self.ge_heteroskedasticity_order,
                beta_regularizer=self.beta_regularizer,
                use_empirical_noise=self.use_empirical_noise)
        
        elif self.ge_noise_model =='skewedt':
            self.noise_layer = SkewedTNoise(
                ge_heteroskedasticity_order=self.ge_heteroskedasticity_order,
                beta_regularizer=self.beta_regularizer,
                use_empirical_noise=self.use_empirical_noise)
        else:
            raise ValueError(f"Unsupported noise model: {self.ge_noise_model}")

        
    def get_config(self):
        """Get configuration for serialization."""
        config = super().get_config()
        config.update({
            'num_hidden_nodes': self.num_hidden_nodes,
            'alpha_regularizer': self.alpha_regularizer,
            'beta_regularizer': self.beta_regularizer,
            'monotonic': self.monotonic,
            'phi_mapping': self.phi_mapping,
            'ge_noise_model': self.ge_noise_model,
            'ge_heteroskedasticity_order': self.ge_heteroskedasticity_order,
            'use_empirical_noise': self.use_empirical_noise,
            'return_type': self.return_type,
            'H_y_norm': self.H_y_norm
        })
        return config

    def build(self, input_shape):
        """
        Instantiate the GlobalEpistasisLayer and a NoiseLayer
        
        Args:
            input_shape: Shape of input tensor (batch, phi_dim)
        """
        # I_var metric
        # Initialize the tracker with the dynamic name
        unique_name = f"{self.name}_I_var"
        self.tracker_I_var = keras.metrics.Mean(name=unique_name)
        
        # Validate input shape
        if len(input_shape) != 2:
            raise ValueError(
                f"Expected 2D input shape (batch, phi_dim), got {input_shape}")        
            
        # Build both layers    
        try:
            self.ge_layer.build(input_shape)
            self.noise_layer.build(input_shape)
        except Exception as e:
            raise ValueError(f"Failed to build layers: {str(e)}")
            

    def phi_to_yhat(self, phi):
        """Compute yhat by calling the instantiated GlobalEpistasisLayer"""
        
        return self.ge_layer.phi_to_yhat(phi)
        
    def p_of_y_given_phi(self, 
                         phi, 
                         y, 
                         empirical_noise = None):
        """Compute p(y|phi)"""
        
        yhat = self.phi_to_yhat(phi)
        return self.noise_layer.p_of_y_given_yhat(yhat=yhat, y=y, empirical_noise=empirical_noise)

    def sample_y_given_phi(self, 
                           phi, 
                           n_samples: int = 1,  # n_sample: number of samples to draw for each phi
                           empirical_noise = None):
        """
        Sample y values from p(y|phi).
        
        Args:
            phi: Input features (batch_size, phi_dim)
            n_samples: Number of samples per input
            empirical_noise: Optional empirical noise values (batch_size, 1)
            
        Returns:
            Sampled y values (batch_size, n_samples)
        """
        
        yhat = self.phi_to_yhat(phi)
        y_sampled = self.noise_layer.sample_y_given_yhat(
            yhat=yhat, 
            n_samples=n_samples, 
            empirical_noise=empirical_noise)
        
        return y_sampled
                                                           
    def negative_log_likelihood(self, phi, y, empirical_noise = None, summed = False):
        """
        Compute negative log likelihoods.
        
        Args:
            phi: Input features (batch_size, phi_dim)
            y: Target values (batch_size, 1)
            empirical_noise: Optional empirical noise values (batch_size, 1)
            summed: Whether to return per-datum NLLs or total NLL
        Returns:
            if summed:
                Scalar : Sum of all NLLs
            else:
                Tensor shape (batch_size, 1) : NLL for each datum
        """
        yhat = self.phi_to_yhat(phi)
        nlls = self.noise_layer.compute_nlls(
            yhat=yhat, 
            ytrue=y, 
            empirical_noise=empirical_noise)
        
        if not summed:
            return nlls
        else:
            return ops.sum(nlls)

    def call(self, phi, y, empirical_noise = None):
        """
        Forward pass computation.
        Add the summed NLLs to loss by add_loss()
        
        Args:
            phi: Input features (batch_size, phi_dim)
            y: Target values (batch_size, 1)
            empirical_noise: Optional empirical noise values (batch_size, 1)
            
        Returns:
            Either nlls or (yhat, other_params) based on return_type
        """
        yhat = self.ge_layer(phi)
        nlls = self.noise_layer(yhat=yhat, y=y, empirical_noise=empirical_noise)

        # I_var metric
        H_y = self.H_y if self.H_y is not None else np.nan
        H_y_given_phi = ops.mean(np.log2(np.exp(1)) * nlls)

        I_var = H_y - H_y_given_phi
        self.tracker_I_var.update_state(I_var)

        # Loss switching for pre-training with MSE loss and then the actual NLL
        mse_loss = keras.losses.MeanSquaredError()(y, yhat)
        loss = ops.where(self.use_mse_loss, mse_loss, nlls)
        self.add_loss(loss)
        
        if self.return_type == 'nlls':
            return nlls
        else:
            other_params = self.noise_layer.compute_params(
                yhat=yhat, 
                empirical_noise=empirical_noise)

            if isinstance(other_params, tuple):
                # If tuple, concatenate yhat with all params
                dist_params = ops.concatenate([yhat] + list(other_params), axis=-1)
            else:
                # If single tensor, just concatenate yhat and other_params
                dist_params = ops.concatenate([yhat, other_params], axis=-1)
            return dist_params

    def get_metrics(self):
        return {"I_var": self.tracker_I_var} 



class GlobalEpistasisLayer(keras.Layer):
    """
    Auxiliary layer to ContinuousMP class
    
    This layer transforms input features (phi) to predicted values (yhat) using either:
    - non-linear: A sum of tanh transformations with trainable weights
    - linear: A standard linear transformation with trainable weights

    Input shape:
        (batch_size, phi_dim) : phi_dim is the dimension of input features
        
    Output shape:
        (batch_size, 1) : Single predicted value for each input

    Example:
        # Non-linear mapping
        layer = GlobalEpistasisLayer(
            num_hidden_nodes=50,
            monotonic=True,
            phi_mapping='non-linear')
    """
    def __init__(self,
                 num_hidden_nodes: int, 
                 alpha_regularizer: Optional[Regularizer], 
                 monotonic: bool, 
                 phi_mapping: str,  # TODO: add linear and identity mapping
                 **kwargs):
        """
        Initialize the GlobalEpistasisLayer
        
        Args:
        num_hidden_nodes: Number of hidden nodes for non-linear mapping (default: 50).
                          Not used for linear mapping.
        alpha_regularizer: Optional regularizer for the weights.
        monotonic: If True, enforces monotonic relationship between phi and yhat
                   by constraining weights to be non-negative.
        phi_mapping: Type of mapping, either 'non-linear', 'linear' or 'identity'
        """
        
        super().__init__(**kwargs)
        self.K = num_hidden_nodes
        self.alpha_regularizer = alpha_regularizer
        self.monotonic = monotonic
        self.phi_mapping = phi_mapping.lower()

        if self.phi_mapping not in ['non-linear', 'linear']:
            raise ValueError(f"Unsupported mapping type: {phi_mapping}. Use 'non-linear' or 'linear'")
            
        # Apply the non-negative constraint on scaling coeffs if monotonic is true
        self.nonneg_constraint = NonNeg() if self.monotonic else None

    def get_config(self):
        config = super().get_config()
        config.update({
            'phi_dim': self.phi_dim,
            'num_hidden_nodes': self.K,
            'alpha_regularizer': self.alpha_regularizer,
            'monotonic': self.monotonic,
            'phi_mapping': self.phi_mapping
        })
        return config

    def build(self, input_shape):
        """Weight initialization for the defined mapping."""
        self.phi_dim = input_shape[-1]

        # Handle weights initialization for linear mapping
        # This ensures correct fan_out for Glorot initialization
        if self.monotonic:
            b_in, b_out = self.K, 1.0
            b_scale = 1.0/np.sqrt(b_in + b_out)
            b_init = lambda shape, dtype: RandomUniform(0, b_scale)(shape, dtype)
    
            c_in, c_out = self.phi_dim, self.K
            if self.phi_mapping == 'linear':
                c_out = 1.0
            c_scale = 1.0/np.sqrt(c_in + c_out) 
            c_init = lambda shape, dtype: RandomUniform(0, c_scale)(shape, dtype)
        else:
            b_init = GlorotUniform()
            c_init = GlorotUniform()

        if self.phi_mapping == 'linear':
            self.c_l = self.add_weight(
                name='c_l',
                shape=(self.phi_dim, 1),
                initializer=c_init,
                trainable=True,
                constraint=self.nonneg_constraint,
                regularizer=self.alpha_regularizer)

            self.d = self.add_weight(
                name='d',
                shape=(1,),
                initializer=Constant(0.),
                trainable=True,
                regularizer=self.alpha_regularizer)

        elif self.phi_mapping == 'non-linear':
            self.a_0 = self.add_weight(name='a_0',
                                       shape=(1,),
                                       initializer=Constant(0.),
                                       trainable=True,
                                       regularizer=self.alpha_regularizer)
        
            self.b_k = self.add_weight(name='b_k',
                                       shape=(self.K,),
                                       initializer=b_init,
                                       trainable=True,
                                       constraint=self.nonneg_constraint,
                                       regularizer=self.alpha_regularizer)

        
            self.c_kl = self.add_weight(name='c_kl',
                                       shape=(self.K, self.phi_dim),
                                       initializer=c_init,
                                       trainable=True,
                                       constraint=self.nonneg_constraint,
                                       regularizer=self.alpha_regularizer)

            self.d_k = self.add_weight(name='d_k',
                                       shape=(self.K,),
                                       initializer=Constant(0.),
                                       trainable=True,
                                       regularizer=self.alpha_regularizer)
        
    def phi_to_yhat(self, phi):
        """
        Computate yhat from phi.
        
        Args:
            phi: Input tensor of shape (batch_size, phi_dim)
            
        Returns:
            yhat: Output tensor of shape (batch_size, 1)
            
        Raises:
            ValueError: If input shape doesn't match layer's input dimension
        """
        input_shape = ops.shape(phi)
        if len(input_shape) != 2 or input_shape[-1] != self.phi_dim:
            raise ValueError(f"Expected input shape (batch, {self.phi_dim}), got {input_shape}")
        
        if self.phi_mapping == 'linear':
            # Linear transformation: phi @ c_l + d
            yhat = ops.matmul(phi, self.c_l) + self.d
            return yhat

        elif self.phi_mapping == 'non-linear':
            phi = ops.reshape(phi, [-1,1,self.phi_dim])
            b_k = ops.reshape(self.b_k, [-1, self.K])
            c_kl = ops.reshape(self.c_kl, [-1, self.K, self.phi_dim])
            d_k = ops.reshape(self.d_k, [-1, self.K])
            yhat = self.a_0 + ops.reshape(ops.sum(b_k * ops.tanh(ops.sum(c_kl * phi, axis=2) + d_k), axis=1), [-1,1])
            return yhat
        
    def call(self, phi):
        """
        Alias for phi_to_yhat, for tensors only. Used by Keras.
        """
        return self.phi_to_yhat(phi)



class NoiseLayer(keras.Layer, ABC):
    """
    Base class for implementing noise models in measurement process for continuous-valued measurements
    
    This abstract class defines the interface for noise models that specify
    the conditional distribution p(y|yhat) of observed values given predictions.

    Input shape:
        yhat: (batch_size, 1) : Predicted values
        y: (batch_size, 1) : True values
        empirical_noise: Optional (batch_size, 1) : Empirical noise values
    """

    # Shared methods
    def __init__(self,
                 ge_heteroskedasticity_order: int, 
                 beta_regularizer: Optional[Regularizer],
                 use_empirical_noise: bool = False,
                 **kwargs):
        
        super().__init__(**kwargs)
        
        self.K = ge_heteroskedasticity_order
        self.beta_regularizer = beta_regularizer
        self.use_empirical_noise = use_empirical_noise

    def p_of_y_given_yhat(self, yhat, y, empirical_noise=None):
        """
        Compute conditional probability p(y|yhat).
        
        Args:
            yhat: Predicted values (batch_size, 1)
            y: True values (batch_size, 1)
            empirical_noise: Optional empirical noise/std (batch_size, 1)
            
        Returns:
            Conditional probabilities (batch_size, 1)
        """        
        nlls = self.compute_nlls(yhat=yhat, ytrue=y, empirical_noise=empirical_noise)
        p_y_given_yhat = Exp(-nlls)
        
        return p_y_given_yhat
        
    def sample_y_given_yhat(self, yhat , n_samples: int, empirical_noise=None):
        """
        Sample y values from p(y|yhat).
        
        Args:
            yhat: Predicted values (batch_size, 1)
            n_samples: Number of samples per input
            empirical_noise: Optional empirical noise/std (batch_size, 1)
            
        Returns:
            Sampled y values (batch_size, n_samples)
        """
        batch_size = yhat.shape[0]
        
        # yhat_expanded Shape: (batch_size, 1) -> (batch_size, n_samples)
        yhat_expanded = ops.repeat(yhat, n_samples, axis=1) 

        # Draw random cumulative density for each sample
        q = keras.random.uniform(
            shape=(batch_size, n_samples),
            minval=0.0,
            maxval=1.0)

        # Compute corresponding quantiles
        y_sampled = self.yhat_to_yq(yhat=yhat_expanded, q=q, empirical_noise=empirical_noise)

        return y_sampled

    def call(self, yhat, y, empirical_noise = None):
        """
        Computes negative log likelihoods, an alias for compute_nlls with handling of nan y.
        
        Args:
            yhat: Predicted values (batch_size, 1)
            y: True values (batch_size, 1)
            empirical_noise: Optional empirical noise/std (batch_size, 1)
        
        Returns:
            Negative log likelihoods (batch_size, 1)

        Raises:
            ValueError: If required inputs are missing or invalid
        """
        # Validate required inputs
        # TODO: change these to check()
        if yhat is None or y is None:
            raise ValueError("Required inputs 'yhat' and 'y' must be provided")
            
        if self.use_empirical_noise and empirical_noise is None:
            raise ValueError("empirical_noise required when use_empirical_noise=True")
        
        # TODO replace NANs with something else (y.mean) and don't let these contribute to ll
        # replace the tensors where nans in ytrue occur with zeros, so that likelihood for
        # that yhat, ypred pair is also zero.
        yhat = ops.where(ops.isnan(y), ops.zeros_like(yhat), yhat)
        y = ops.where(ops.isnan(y), ops.zeros_like(y), y)
        
        nlls = self.compute_nlls(yhat=yhat, 
                                 ytrue=y, 
                                 empirical_noise = empirical_noise if self.use_empirical_noise else None)
        
        return nlls

    def get_config(self):
        config = super().get_config()
        config.update({
            'beta_regularizer': self.beta_regularizer,
            'ge_heteroskedasticity_order': self.K,
            'use_empirical_noise': self.use_empirical_noise,
        })
        return config    
        
    # Unique methods
    @abstractmethod
    def build(self, input_shape):
        """
        Initialize weights for noise model p(y|yhat) parameters.
        
        Args:
            input_shape: Shape of input tensor (batch_size, 1)
        """
        pass
        
    @abstractmethod
    def compute_params(self, yhat, empirical_noise=None):
        """
        Computes noise distribution parameters.
        
        Args:
            yhat: Predicted values (batch_size, 1)
            empirical_noise: Optional empirical noise values (batch_size, 1)
            
        Returns:
            if 'Gaussian': (batch_size, 1)
            if 'Cauchy':
            if 'SkewedT':
        """
        pass
        
    @abstractmethod
    def compute_nlls(self, yhat, ytrue, empirical_noise=None):
        """
        Compute negative log likelihood for noise distribution.
        
        Args:
            yhat: Predicted values (batch_size, 1)
            ytrue: True values (batch_size, 1) 
            empirical_noise: Optional empirical noise values (batch_size, 1)
            
        Returns:
            Negative log likelihoods (batch_size, 1)
        """
        pass
        
    @abstractmethod
    def yhat_to_yq(self, yhat, q, empirical_noise=None):
        """Compute quantiles of p(y|yhat), i.e. the inverse CDF/quantile function
        
        Args:
            yhat: Predicted values (batch_size, n_samples)
            q: Quantile values (batch_size, n_samples)
            empirical_noise: Optional empirical noise values (batch_size, 1)
            
        Returns:
            Quantile values (batch_size, n_samples)
        """
        pass

    @abstractmethod
    def yhat_to_ymean(self, yhat):
        """Compute the mean of p(y|yhat)"""
        pass 
        
    @abstractmethod
    def yhat_to_ystd(self, yhat, empirical_noise=None):
        """Compute the standard deviation of p(y|yhat)"""
        pass




class GaussianNoise(NoiseLayer):
    """Represents a Gaussian noise model for GE regression."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def build(self, input_shape):
        """Initialize the polynomial coefficients for log(sigma)."""
        self.a = self.add_weight(name='a',
                                 shape=(self.K + 1, 1),
                                 initializer='truncated_normal',
                                 trainable=True,
                                 regularizer=self.beta_regularizer)
        
    def compute_params(self, yhat, empirical_noise=None):
        """Compute log(sigma) governing p(y|yhat) as a polynomial in yhat."""
        
        if empirical_noise is not None and self.use_empirical_noise:
            sigma = ops.cast(empirical_noise, dtype='float32')
            
            # Check that ALL values are non-negative
            # The function check() needs MAVENN2 imports
            check(ops.all(sigma >= 0),
                  f'Sigma (i.e. standard deviation) can not be negative by definition.')
            
            # Clip sigma to a minimum value
            sigma = ops.maximum(sigma, 1e-8)
            logsigma = Log(sigma)
        else:
            # Have to treat 0'th order term separately because of NaN bug.
            # Always broadcast the zero-order term
            batch_size = ops.shape(yhat)[0]
            logsigma = ops.repeat(self.a[0], batch_size)  # Replace broadcast_to
            logsigma = ops.reshape(logsigma, (-1, 1))  # Ensure (batch_size, 1) shape
        
            # Add higher order terms and return
            for k in range(1, self.K + 1):
                logsigma += self.a[k] * ops.power(yhat, k)

        return logsigma

    def compute_nlls(self, yhat, ytrue, empirical_noise=None):
        """Compute negative log likelihood contributions for each datum."""

        logsigma = self.compute_params(yhat, empirical_noise)
        sigma = Exp(logsigma)

        # Compute NLL: -log(N(y|yhat,sigma))
        nlls = 0.5 * ops.square((ytrue - yhat) / sigma) \
            + logsigma \
            + 0.5 * ops.log(2 * pi)
        
        return nlls

    def yhat_to_yq(self, yhat, q, empirical_noise=None):
        """Compute quantiles for p(y|yhat)."""
        sigma = Exp(self.compute_params(yhat, empirical_noise))
        yq = yhat + sigma * ops.sqrt(2.0) * ops.erfinv(2.0 * q - 1.0)
        return yq

    def yhat_to_ymean(self, yhat):
        """Compute mean of p(y|yhat)."""
        return yhat

    def yhat_to_ystd(self, yhat, empirical_noise=None):
        """Compute standard deviation of 
        p(y|yhat)."""
        sigma = Exp(self.compute_params(yhat, empirical_noise))
        return sigma



class CauchyNoise(NoiseLayer):
    """Represents a Cauchy noise model for GE regression."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def build(self, input_shape):
        """Initialize the polynomial coefficients for log(gamma)."""
        self.a = self.add_weight(name='a',
                                 shape=(self.K + 1, 1),
                                 initializer='truncated_normal',
                                 trainable=True,
                                 regularizer=self.beta_regularizer)
        
    def compute_params(self, yhat, empirical_noise=None):
        """Compute log(gamma) governing p(y|yhat) as a polynomial in yhat."""
        # Have to treat 0'th order term separately because of NaN bug.
        # Always broadcast the zero-order term
        # loggamma = ops.broadcast_to(self.a[0], yhat.shape)

        # Handle symbolic shape
        batch_size = ops.shape(yhat)[0]
        loggamma = ops.repeat(self.a[0], batch_size)  # Replace broadcast_to
        loggamma = ops.reshape(loggamma, (-1, 1))  # Ensure (batch_size, 1) shape
        
        # Add higher order terms and return
        for k in range(1, self.K + 1):
            loggamma += self.a[k] * ops.power(yhat, k)

        return loggamma

    def compute_nlls(self, yhat, ytrue, empirical_noise=None):
        """Compute negative log likelihood contributions for each datum."""

        loggamma = self.compute_params(yhat, empirical_noise)

        # Compute NLL: -log(N(y|yhat,gamma))
        nlls = Log(Exp(2 * loggamma) + ops.square(ytrue - yhat)) \
            - loggamma \
            + ops.log(pi)

        return nlls

    def yhat_to_yq(self, yhat, q, empirical_noise=None):
        """Compute quantiles for p(y|yhat)."""
        gamma = Exp(self.compute_params(yhat, empirical_noise))
        yq = yhat + gamma * ops.tan(pi * (q - 0.5))
        return yq

    def yhat_to_ymean(self, yhat):
        """Compute mean of p(y|yhat)."""
        return yhat

    def yhat_to_ystd(self, yhat, empirical_noise=None):
        """Compute standard deviation of p(y|yhat)."""
        gamma = Exp(self.compute_params(yhat, empirical_noise))
        return gamma



class SkewedTNoise(NoiseLayer):
    """Represents a skewed-t noise model for GE regression."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def build(self, input_shape):
        """Initialize the polynomial coefficients for s, a, b."""
        self.w_a = self.add_weight(name='w_a',
                                   shape=(self.K + 1, 1),
                                   initializer='truncated_normal',
                                   trainable=True,
                                   regularizer=self.beta_regularizer)

        self.w_b = self.add_weight(name='w_b',
                                   shape=(self.K + 1, 1),
                                   initializer='truncated_normal',
                                   trainable=True,
                                   regularizer=self.beta_regularizer)

        self.w_s = self.add_weight(name='w_s',
                                   shape=(self.K + 1, 1),
                                   initializer='truncated_normal',
                                   trainable=True,
                                   regularizer=self.beta_regularizer)

    def t_mode(self, a, b):
        """Compute mode of p(t|a,b), as a function of a and b"""
        t_mode = (a - b) * ops.sqrt(a + b) \
            / (ops.sqrt(2 * a + 1) * ops.sqrt(2 * b + 1))
        return t_mode

    def t_mean(self, a, b):
        """Compute mean of p(t|a,b)."""
        return 0.5 * (a - b) * ops.sqrt(a + b) * ops.exp(
            LogGamma(a - 0.5)
            + LogGamma(b - 0.5)
            - LogGamma(a)
            - LogGamma(b))

    def t_std(self, a, b):
        """Compute standard devaition of p(t|a,b)."""
        t_expected = self.t_mean(a, b)
        tsq_expected = 0.25 * (a + b) * \
            ((a - b) ** 2 + (a - 1) + (b - 1)) / ((a - 1) * (b - 1))
        return ops.sqrt(tsq_expected - t_expected ** 2)

    def t_quantile(self, q, a, b):
        """Compute quantiles of p(t|a,b)."""
        x_q = ops.convert_to_tensor(betaincinv(ops.convert_to_numpy(a),
                                               ops.convert_to_numpy(b), 
                                               ops.convert_to_numpy(q)),
                                    dtype='float32')
        
        t_q = (2 * x_q - 1) * ops.sqrt(a + b) / ops.sqrt(1 - (2 * x_q - 1) ** 2)
        return t_q

    def compute_params(self, yhat, empirical_noise=None):
        """Compute layer parameters governing p(y|yhat)."""
        # Have to treat 0'th order term separately because of NaN bug.

        batch_size = ops.shape(yhat)[0]
        log_a = ops.repeat(self.w_a[0], batch_size)  # Replace broadcast_to
        log_a = ops.reshape(log_a, (-1, 1))  # Ensure (batch_size, 1) shape
        log_b = ops.repeat(self.w_b[0], batch_size)  
        log_b = ops.reshape(log_b, (-1, 1))  
        log_s = ops.repeat(self.w_s[0], batch_size)  
        log_s = ops.reshape(log_s, (-1, 1))  
        
        # log_a = ops.broadcast_to(self.w_a[0], yhat.shape)
        # log_b = ops.broadcast_to(self.w_b[0], yhat.shape)
        # log_s = ops.broadcast_to(self.w_s[0], yhat.shape)

        # Add higher order terms and return
        for k in range(1, self.K + 1):
            log_a += self.w_a[k] * ops.power(yhat, k)
            log_b += self.w_b[k] * ops.power(yhat, k)
            log_s += self.w_s[k] * ops.power(yhat, k)

        # Compute a, b, s in terms of trainable parameters
        a = Exp(log_a)
        b = Exp(log_b)
        s = Exp(log_s)

        # Clip values to keep a and b in safe ranges
        a = ops.clip(a, 0.01, np.inf)
        b = ops.clip(b, 0.01, np.inf)

        return a, b, s

    def compute_nlls(self, yhat, ytrue, empirical_noise=None):
        # Compute distribution parameters at yhat values
        a, b, s = self.compute_params(yhat)

        # Compute t_mode
        t_mode = self.t_mode(a, b)

        # Compute t values
        t = t_mode + (ytrue - yhat) / s

        # Compute useful argument
        arg = t / ops.sqrt(a + b + ops.square(t))

        # Compute negative log likelihood contributions
        nlls = -(
            (a + 0.5) * Log(1 + arg) +
            (b + 0.5) * Log(1 - arg) +
            -(a + b - 1) * Log(ops.cast(2.0, dtype='float32')) +
            -0.5 * Log(a + b) +
            LogGamma(a + b) +
            -LogGamma(a) +
            -LogGamma(b) +
            -Log(s)
        )

        # nlls =  -(a + 0.5) * Log(1.0 + arg)
        # nlls += -(b + 0.5) * Log(1.0 - arg)
        # nlls += (a + b - 1.0) * Log(np.float32(2.0))
        # nlls += 0.5 * Log(a + b)
        # nlls += -LogGamma(a + b)
        # nlls += LogGamma(a)
        # nlls += LogGamma(b)
        # nlls += Log(s)
        return nlls

    def yhat_to_yq(self, yhat, q, empirical_noise=None):
        """Compute quantiles for p(y|yhat)."""
        # Compute distribution parameters at yhat values
        a, b, s = self.compute_params(yhat)

        # Compute t_mode
        t_mode = self.t_mode(a, b)

        # Compute random t values
        t_q = self.t_quantile(q, a, b)

        # Compute and return y
        yq = (t_q - t_mode) * s + yhat
        return yq

    def yhat_to_ymean(self, yhat):
        """Compute mean of p(y|yhat)."""
        # Compute distribution parameters at yhat values
        a, b, s = self.compute_params(yhat)

        # Compute mean and mode of t distribution
        t_mean = self.t_mean(a, b)
        t_mode = self.t_mode(a, b)

        # Compute ymean
        ymean = s * (t_mean - t_mode) + yhat

        return ymean

    def yhat_to_ystd(self, yhat, empirical_noise=None):
        """Compute standard deviation of p(y|yhat)."""
        # Compute distribution parameters at yhat values
        a, b, s = self.compute_params(yhat)

        # Compute tstd
        tstd = self.t_std(a, b)

        # Compute and return ystd
        ystd = s * tstd

        return ystd
