#%%capture
import sys
sys.path.insert(0, '../mavenn')
sys.path.insert(0, './x_to_ohe.py')
sys.path.insert(0, './GPMap.py')
sys.path.insert(0, './MeasurementProcess.py')
sys.path.insert(0, './ResidualBind.py')
sys.path.insert(0, './pearsonr_score.py')

from x_to_ohe import x_to_ohe
import GPMap
import MeasurementProcess
from ResidualBind import ResidualBind
from pearsonr_score import pearsonr_score

import mavenn
from mavenn.src.error_handling import check, handle_errors
from mavenn.src.entropy import mi_continuous, mi_mixed, entropy_continuous
from mavenn import TINY

import keras
from keras import Input, Layer, ops
from keras.initializers import Constant, GlorotUniform
from keras.constraints import NonNeg
from keras.regularizers import Regularizer, L2

import time
import numpy as np
import re
from abc import ABC, abstractmethod
from typing import Optional
import sklearn
from scipy import stats
from scipy.stats import expon
import matplotlib.pyplot as plt

import os
import helper

data_df = mavenn.load_example_dataset('mpsa')
L = len(data_df.loc[0,'x'])
print(f'Sequence length: {L:d} RNA nucleotides')
trainval_df, test_df = mavenn.split_dataset(data_df)
print('\ntrainval_df:')

train_df = trainval_df.loc[trainval_df['validation'] == False]
train_df.reset_index(inplace=True)
train_x = ops.cast(x_to_ohe(train_df['x'],alphabet=['A','C','G','U'],ravel_seqs=False).transpose(0, 2, 1), dtype='float32')
train_y = ops.cast(train_df['y'].to_numpy().reshape([-1,1]), dtype='float32')

val_df = trainval_df.loc[trainval_df['validation'] == True]
val_df.reset_index(inplace=True)
val_x = ops.cast(x_to_ohe(val_df['x'],alphabet=['A','C','G','U'],ravel_seqs=False).transpose(0, 2, 1), dtype='float32')
val_y = ops.cast(val_df['y'].to_numpy().reshape([-1,1]), dtype='float32')

test_x = ops.cast(x_to_ohe(test_df['x'],alphabet=['A','C','G','U'],ravel_seqs=False).transpose(0, 2, 1), dtype='float32')
test_y = ops.cast(test_df['y'].to_numpy().reshape([-1,1]), dtype='float32')

def pearsonr_score(y_true, y_pred, mask_value=None):
    corr = []
    for i in range(y_true.shape[1]):
        if mask_value:
            index = np.where(y_true[:,i] != mask_value)[0]
            corr.append(stats.pearsonr(y_true[index,i], y_pred[index,i])[0])
        else:
            corr.append(stats.pearsonr(y_true[:,i], y_pred[:,i])[0])
    return np.array(corr)



normalization = 'no_norm'   # 'log_norm' or 'clip_norm'
ss_type = 'seq'                  # 'seq', 'pu', or 'struct'
phi_mapping = 'linear'
ge_noise_model = 'gaussian'
ge_heteroskedasticity_order = 0
data_path = './data/RNAcompete_2013/rnacompete2013.h5'
results_path = helper.make_directory('./results', 'rnacompete_2013')
save_path = helper.make_directory(results_path, normalization+'_'+ss_type+'_'+"_".join(sys.argv))
print(save_path)



# loop over different RNA binding proteins
keras.utils.clear_session(free_memory=True)
experiments = helper.get_experiment_names(data_path)
training_times_path = os.path.join(results_path, normalization+'_'+ss_type+'_'+"_".join(sys.argv)+'_training_time.tsv')
training_times = open(training_times_path, 'w')
training_times.write('%s\t%s\n'%('Experiment', 'Training time'))
training_times.close()
pearsonr_scores_path = os.path.join(results_path, normalization+'_'+ss_type+'_'+"_".join(sys.argv)+'_performance.tsv')
pearsonr_scores = open(pearsonr_scores_path, 'w')
pearsonr_scores.write('%s\t%s\n'%('Experiment', 'Pearson score'))
pearsonr_scores.close()
for rbp_index, experiment in enumerate(experiments):
    print('Analyzing: '+ experiment)

    # load rbp dataset
    train, valid, test = helper.load_rnacompete_data(data_path, 
                                                     ss_type=ss_type, 
                                                     normalization=normalization, 
                                                     rbp_index=rbp_index)

    # load residualbind model
    input_shape = list(train['inputs'].shape)[1:]
    num_class = 1
    weights_path = os.path.join(save_path, experiment + '_weights.hdf5')  

    input_x = Input(shape=input_shape)
    input_y = Input(shape=(1,))

    # Instantiate residualbind and extract the keras functional model object through .model attribute 
    residualbind = ResidualBind(input_shape=input_shape)
    gp = residualbind.model(input_x)

    mp = MeasurementProcess.ContinuousMP(
        num_hidden_nodes=50,
        monotonic=True,
        phi_mapping=sys.argv[1],
        ge_noise_model=sys.argv[2],
        ge_heteroskedasticity_order = int(sys.argv[3]),
        alpha_regularizer=L2(0.001),
        beta_regularizer=L2(0.1),
        H_y = np.nan)(gp, input_y)

    model = keras.Model(inputs=[input_x, input_y], outputs=mp)
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.005))
    model.summary()

    callbacks = [keras.callbacks.EarlyStopping(
        monitor='val_loss',
        patience=10,
        restore_best_weights=True)]

    # # For training:
    # # Assuming you have your data as X and y
    start_time = time.time()
    history = model.fit(
        x=[train['inputs'], train['targets']],  # input data
        y=None,    # No y needed as loss is computed in MP layer
        batch_size=256,
        epochs=30,
        validation_data=([valid['inputs'], valid['targets']], None),
        verbose=1,
        callbacks=callbacks)
    training_time = time.time()-start_time
    training_times = open(training_times_path, 'a')
    training_times.write('%s\t%.4f\n'%(experiment, training_time))
    training_times.close()
        
    # evaluate model
    test_predictions = model.predict([test['inputs'], test['targets']]) #, batch_size=100, load_weights='best'
    metrics = pearsonr_score(test['targets'], test_predictions)
    print("  Test: "+str(np.mean(metrics)))
    pearsonr_scores = open(pearsonr_scores_path, 'a')
    pearsonr_scores.write('%s\t%.4f\n'%(experiment, np.array(metrics)))
    pearsonr_scores.close()

print('FINAL RESULTS: %.4f+/-%.4f'%(np.mean(pearsonr_scores), np.std(pearsonr_scores)))
pearsonr_scores.close()

